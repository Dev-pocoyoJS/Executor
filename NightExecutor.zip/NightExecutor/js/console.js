/* ════════════════════════════════════════
   NightExec — console.js
   Console de output e input rápido
   ════════════════════════════════════════ */

const ConsoleMgr = (() => {
  let logCount  = 0;
  let filters   = { log: true, warn: true, err: true, sys: true };

  const output = () => document.getElementById('conOutput');
  const badge  = () => document.getElementById('consoleBadge');

  const ts = () => {
    const d = new Date();
    return [d.getHours(), d.getMinutes(), d.getSeconds()]
      .map(n => String(n).padStart(2, '0')).join(':');
  };

  // ── ADICIONAR LINHA ──────────────────────
  const addLine = (type, msg) => {
    if (!filters[type]) return;

    const out = output();
    if (!out) return;

    const line = document.createElement('div');
    line.className = `con-line ${type}`;
    line.innerHTML = `<span class="con-ts">${ts()}</span><span>${escapeHtml(String(msg))}</span>`;
    out.appendChild(line);
    out.scrollTop = out.scrollHeight;

    // Badge na tab
    logCount++;
    const b = badge();
    if (b && document.querySelector('.tnav[data-tab="console"]')?.classList.contains('active') === false) {
      b.style.display = 'flex';
      b.textContent   = logCount > 99 ? '99+' : logCount;
    }

    DB.addLog(type, String(msg));
  };

  const log  = (msg) => addLine('log',  msg);
  const warn = (msg) => addLine('warn', '⚠ ' + msg);
  const err  = (msg) => addLine('err',  '✗ ' + msg);
  const sys  = (msg) => addLine('sys',  '◈ ' + msg);

  const escapeHtml = (s) => s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // ── LIMPAR ───────────────────────────────
  const clear = () => {
    const out = output();
    if (out) out.innerHTML = '';
    logCount = 0;
    const b = badge();
    if (b) b.style.display = 'none';
  };

  // ── COPIAR LOGS ──────────────────────────
  const copyAll = () => {
    const out = output();
    if (!out) return;
    const text = Array.from(out.querySelectorAll('.con-line'))
      .map(l => l.textContent).join('\n');
    navigator.clipboard.writeText(text).then(() => Toast.show('✓ Logs copiados!'));
  };

  // ── INIT ─────────────────────────────────
  const init = () => {
    // Filtros
    ['Log','Warn','Err','Sys'].forEach(t => {
      const el = document.getElementById('flt' + t);
      if (el) {
        const key = t.toLowerCase();
        el.checked = filters[key];
        el.onchange = () => {
          filters[key] = el.checked;
          // Mostra/oculta linhas existentes
          output()?.querySelectorAll(`.con-line.${key}`)
            .forEach(l => l.style.display = el.checked ? '' : 'none');
        };
      }
    });

    document.getElementById('btnClearCon')?.addEventListener('click', clear);
    document.getElementById('btnCopyCon')?.addEventListener('click', copyAll);

    // Input rápido
    const input = document.getElementById('conInput');
    const runBtn = document.getElementById('btnConRun');

    const runInput = () => {
      const code = input?.value?.trim();
      if (!code) return;
      sys('> ' + code);
      Executor.run(code);
      input.value = '';
    };

    runBtn?.addEventListener('click', runInput);
    input?.addEventListener('keydown', e => {
      if (e.key === 'Enter') runInput();
    });

    // Limpa badge ao abrir console
    document.querySelector('.tnav[data-tab="console"]')?.addEventListener('click', () => {
      logCount = 0;
      const b = badge();
      if (b) b.style.display = 'none';
    });

    sys('NightExec v3.0 inicializado');
  };

  return { init, log, warn, err, sys, clear, copyAll };
})();
