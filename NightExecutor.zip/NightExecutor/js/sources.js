/* ════════════════════════════════════════
   NightExec — sources.js
   Busca sources (scripts) de URLs externas
   ════════════════════════════════════════ */

const Sources = (() => {

  // ── PRESETS DE SOURCES CONHECIDAS ───────
  const PRESETS = [
    {
      name: 'Infinite Yield',
      url: 'https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source',
      desc: 'Admin commands universal',
      cat: 'misc',
    },
    {
      name: 'Dex Explorer',
      url: 'https://raw.githubusercontent.com/infyiff/backup/main/dex.lua',
      desc: 'Explorer de instâncias do jogo',
      cat: 'misc',
    },
    {
      name: 'Simple Spy',
      url: 'https://raw.githubusercontent.com/exxtremestuffs/SimpleSpySource/master/SimpleSpy.lua',
      desc: 'Remote Spy - monitora RemoteEvents',
      cat: 'misc',
    },
    {
      name: 'Dark Dex v3',
      url: 'https://raw.githubusercontent.com/Moon-Mining-Roblox/moonsuite/main/DarkDex',
      desc: 'Explorador de hierarquia Roblox',
      cat: 'misc',
    },
    {
      name: 'Hydroxide',
      url: 'https://raw.githubusercontent.com/Upbolt/Hydroxide/revision/src/init.lua',
      desc: 'Hook e monitor de remotes avançado',
      cat: 'misc',
    },
    {
      name: 'Owl Hub',
      url: 'https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.lua',
      desc: 'Hub de scripts multi-jogo',
      cat: 'farm',
    },
  ];

  // ── CACHE FETCH ─────────────────────────
  const cache = new Map();

  const fetchSource = async (url) => {
    if (!url || !url.startsWith('http')) {
      throw new Error('URL inválida');
    }

    // Cache de 5 minutos
    if (cache.has(url)) {
      const { data, ts } = cache.get(url);
      if (Date.now() - ts < 5 * 60 * 1000) return data;
    }

    // Tenta proxies CORS conhecidos
    const proxies = [
      (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
      (u) => `https://corsproxy.io/?${encodeURIComponent(u)}`,
      (u) => u, // Direto (funciona se não houver CORS)
    ];

    let lastErr = null;
    for (const makeUrl of proxies) {
      try {
        const res = await fetch(makeUrl(url), {
          method: 'GET',
          headers: { 'Accept': 'text/plain, */*' },
          signal: AbortSignal.timeout(10000),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        if (!text || text.length < 5) throw new Error('Resposta vazia');
        cache.set(url, { data: text, ts: Date.now() });
        return text;
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr || new Error('Falha ao buscar source');
  };

  // ── DETECTA SE É LUA ────────────────────
  const isLua = (text) => {
    return text.includes('local ') ||
           text.includes('function ') ||
           text.includes('game:') ||
           text.includes('--') ||
           text.includes('end');
  };

  // ── RESUME (primeiras linhas) ────────────
  const preview = (text, lines = 12) =>
    text.split('\n').slice(0, lines).join('\n');

  return { PRESETS, fetchSource, isLua, preview };
})();


/* ── UI DO SOURCE FETCHER ────────────────── */
const SourceUI = (() => {

  let currentCode = '';

  const modal  = document.getElementById('sourcesModal');
  const urlInp = document.getElementById('sfUrl');
  const fetchBtn = document.getElementById('sfFetch');
  const presets  = document.getElementById('sfPresets');
  const status   = document.getElementById('sfStatus');
  const preview  = document.getElementById('sfPreview');
  const actions  = document.getElementById('sfActions');
  const loadBtn  = document.getElementById('sfLoad');
  const execBtn  = document.getElementById('sfExec');
  const closeBtn = document.getElementById('sourcesClose');

  // Renderiza presets
  const renderPresets = () => {
    presets.innerHTML = '';
    Sources.PRESETS.forEach(p => {
      const btn = document.createElement('button');
      btn.className = 'sf-preset';
      btn.textContent = p.name;
      btn.title = p.desc;
      btn.onclick = () => {
        urlInp.value = p.url;
        doFetch(p.url);
      };
      presets.appendChild(btn);
    });
  };

  const setStatus = (msg, type = '') => {
    status.textContent = msg;
    status.className = 'sf-status ' + type;
  };

  const doFetch = async (url) => {
    url = url || urlInp.value.trim();
    if (!url) { setStatus('⚠ Insira uma URL', 'err'); return; }

    fetchBtn.classList.add('loading');
    fetchBtn.textContent = '⏳';
    setStatus('Buscando source...', 'load');
    preview.classList.remove('show');
    actions.classList.add('hidden');
    currentCode = '';

    try {
      const code = await Sources.fetchSource(url);
      currentCode = code;

      const lineCount = code.split('\n').length;
      const size = (code.length / 1024).toFixed(1);
      const isLua = Sources.isLua(code);

      setStatus(
        `✓ Source carregada! ${lineCount} linhas · ${size}KB · ${isLua ? 'Lua detectado' : 'Formato desconhecido'}`,
        'ok'
      );

      preview.textContent = Sources.preview(code, 15) + '\n...';
      preview.classList.add('show');
      actions.classList.remove('hidden');

    } catch (e) {
      setStatus('✗ Erro: ' + e.message, 'err');
    }

    fetchBtn.classList.remove('loading');
    fetchBtn.textContent = 'Buscar';
  };

  const init = () => {
    renderPresets();

    fetchBtn.onclick = () => doFetch(urlInp.value.trim());

    urlInp.addEventListener('keydown', e => {
      if (e.key === 'Enter') doFetch(urlInp.value.trim());
    });

    loadBtn.onclick = () => {
      if (!currentCode) return;
      EditorMgr.setCode(currentCode);
      open(false);
      Toast.show('✓ Source carregada no editor!');
    };

    execBtn.onclick = () => {
      if (!currentCode) return;
      Executor.run(currentCode);
      open(false);
    };

    closeBtn.onclick = () => open(false);
    modal.onclick = (e) => { if (e.target === modal) open(false); };
  };

  const open = (show = true) => {
    if (show) {
      modal.classList.remove('hidden');
      renderPresets();
    } else {
      modal.classList.add('hidden');
    }
  };

  return { init, open };
})();
