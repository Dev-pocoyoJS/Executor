/* ════════════════════════════════════════
   NightExec — settings.js
   ════════════════════════════════════════ */

const SettingsMgr = (() => {

  const SCHEMA = [
    { section: 'EDITOR' },
    {
      key: 'fontSize', label: 'Tamanho da Fonte',
      desc: 'Tamanho do texto no editor',
      type: 'range', min: 10, max: 20, def: 13,
    },
    {
      key: 'tabSize', label: 'Tamanho do Tab',
      desc: 'Espaços por indentação',
      type: 'range', min: 2, max: 8, def: 2,
    },
    {
      key: 'wordWrap', label: 'Word Wrap',
      desc: 'Quebra linhas longas automaticamente',
      type: 'toggle', def: false,
    },

    { section: 'EXECUTOR' },
    {
      key: 'autoAttach', label: 'Auto Attach',
      desc: 'Conecta automaticamente ao abrir',
      type: 'toggle', def: false,
    },
    {
      key: 'notifications', label: 'Notificações',
      desc: 'Mostrar toast ao executar',
      type: 'toggle', def: true,
    },
    {
      key: 'keepHistory', label: 'Histórico de Execução',
      desc: 'Guardar histórico de scripts executados',
      type: 'toggle', def: true,
    },

    { section: 'VISUAL' },
    {
      key: 'opacity', label: 'Opacidade da UI',
      desc: 'Transparência geral da interface',
      type: 'range', min: 60, max: 100, def: 100, unit: '%',
    },
    {
      key: 'theme', label: 'Tema',
      desc: 'Esquema de cores',
      type: 'select',
      options: [
        { val: 'dark',  label: 'Dark (Padrão)' },
        { val: 'abyss', label: 'Abyss' },
        { val: 'red',   label: 'Red Neon' },
      ],
      def: 'dark',
    },

    { section: 'DADOS' },
    {
      key: '_clearHistory', label: 'Limpar Histórico',
      desc: 'Remove todos os scripts do histórico',
      type: 'danger', label2: '🗑 Limpar',
      action: () => { DB.del('history'); Toast.show('✓ Histórico limpo'); },
    },
    {
      key: '_clearAll', label: 'Reset Completo',
      desc: 'Apaga TODAS as configurações e dados',
      type: 'danger', label2: '⚠ Reset',
      action: () => {
        if (confirm('Apagar TODOS os dados? Isso não pode ser desfeito!')) {
          DB.clear();
          location.reload();
        }
      },
    },
  ];

  const settings = () => DB.getSettings();

  // ── RENDERIZAR ───────────────────────────
  const render = () => {
    const list = document.getElementById('setList');
    if (!list) return;
    list.innerHTML = '';

    SCHEMA.forEach(item => {
      // Seção
      if (item.section) {
        const title = document.createElement('div');
        title.className = 'set-section-title';
        title.textContent = item.section;
        list.appendChild(title);
        return;
      }

      const cfg  = settings();
      const val  = cfg[item.key] ?? item.def;

      const div = document.createElement('div');
      div.className = 'set-item' + (item.type === 'danger' ? ' danger' : '');

      let control = '';

      if (item.type === 'toggle') {
        const checked = val ? 'checked' : '';
        control = `
          <label class="sw">
            <input type="checkbox" data-key="${item.key}" ${checked} />
            <div class="sw-track"></div>
            <div class="sw-thumb"></div>
          </label>`;
      } else if (item.type === 'range') {
        control = `
          <div class="set-slider">
            <input type="range" class="set-range" data-key="${item.key}"
              min="${item.min}" max="${item.max}" value="${val}" />
            <span class="set-range-val" id="rv_${item.key}">${val}${item.unit || ''}</span>
          </div>`;
      } else if (item.type === 'select') {
        const opts = item.options.map(o =>
          `<option value="${o.val}" ${val === o.val ? 'selected' : ''}>${o.label}</option>`
        ).join('');
        control = `<select class="set-select" data-key="${item.key}">${opts}</select>`;
      } else if (item.type === 'danger') {
        control = `<button class="set-danger-btn" data-key="${item.key}">${item.label2}</button>`;
      }

      div.innerHTML = `
        <div class="set-info">
          <div class="set-label">${item.label}</div>
          <div class="set-desc">${item.desc}</div>
        </div>
        ${control}
      `;

      list.appendChild(div);

      // Eventos
      if (item.type === 'toggle') {
        div.querySelector('input')?.addEventListener('change', (e) => {
          DB.saveSetting(item.key, e.target.checked);
          applySettings();
        });
      } else if (item.type === 'range') {
        div.querySelector('input')?.addEventListener('input', (e) => {
          const v = parseInt(e.target.value);
          DB.saveSetting(item.key, v);
          const lbl = document.getElementById('rv_' + item.key);
          if (lbl) lbl.textContent = v + (item.unit || '');
          applySettings();
        });
      } else if (item.type === 'select') {
        div.querySelector('select')?.addEventListener('change', (e) => {
          DB.saveSetting(item.key, e.target.value);
          applySettings();
        });
      } else if (item.type === 'danger') {
        div.querySelector('button')?.addEventListener('click', item.action);
      }
    });
  };

  // ── APLICAR SETTINGS ─────────────────────
  const applySettings = () => {
    const cfg = settings();

    // Fonte do editor
    document.dispatchEvent(new CustomEvent('nightexec:fontsize', { detail: cfg.fontSize }));

    // Word wrap
    const ed = document.getElementById('codeEditor');
    if (ed) ed.style.whiteSpace = cfg.wordWrap ? 'pre-wrap' : 'pre';

    // Opacidade
    document.body.style.opacity = (cfg.opacity / 100).toFixed(2);

    // Tema
    document.documentElement.setAttribute('data-theme', cfg.theme);
    applyTheme(cfg.theme);
  };

  const applyTheme = (theme) => {
    const themes = {
      abyss: {
        '--bg0': '#000008', '--bg1': '#030310', '--bg2': '#060618',
        '--cyan': '#5555ff', '--cyan2': '#4444cc', '--blue': '#0000ff',
      },
      red: {
        '--bg0': '#100005', '--bg1': '#150008', '--bg2': '#1a000a',
        '--cyan': '#ff0055', '--cyan2': '#cc0044', '--blue': '#ff3300',
      },
    };
    const root = document.documentElement;
    // Reset
    ['--bg0','--bg1','--bg2','--cyan','--cyan2','--blue'].forEach(v =>
      root.style.removeProperty(v)
    );
    if (themes[theme]) {
      Object.entries(themes[theme]).forEach(([k, v]) =>
        root.style.setProperty(k, v)
      );
    }
  };

  const init = () => {
    render();
    applySettings();
  };

  return { init, render, applySettings };
})();
