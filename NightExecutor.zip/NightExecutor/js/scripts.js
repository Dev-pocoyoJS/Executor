/* ════════════════════════════════════════
   NightExec — scripts.js
   Scripts embutidos + gerenciamento
   ════════════════════════════════════════ */

const ScriptsMgr = (() => {

  // ── SCRIPTS EMBUTIDOS ────────────────────
  const BUILT_IN = [
    // ═══ COMBATE ═══
    {
      id: 'kill_aura',
      name: 'Kill Aura',
      cat: 'combat',
      desc: 'Mata todos os NPCs num raio automático',
      code: `local Players = game:GetService("Players")
local RS = game:GetService("RunService")
local LP = Players.LocalPlayer
local raio = 60

local conn
conn = RS.Heartbeat:Connect(function()
  local hrp = LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
  if not hrp then return end
  for _, v in ipairs(game.Workspace:GetDescendants()) do
    if v:IsA("Humanoid") and v.Health > 0 and v.Parent ~= LP.Character then
      local root = v.Parent:FindFirstChild("HumanoidRootPart")
      if root and (root.Position - hrp.Position).Magnitude <= raio then
        pcall(function() v.Health = 0 end)
      end
    end
  end
end)
print("[Kill Aura] Ativo! Raio: " .. raio)`,
    },
    {
      id: 'godmod',
      name: 'Godmod',
      cat: 'combat',
      desc: 'Invulnerabilidade total',
      code: `local LP = game:GetService("Players").LocalPlayer
local RS = game:GetService("RunService")

local conn
conn = RS.Heartbeat:Connect(function()
  local c = LP.Character
  local h = c and c:FindFirstChildOfClass("Humanoid")
  if h then h.Health = h.MaxHealth end
end)
print("[Godmod] Ativo!")`,
    },
    {
      id: 'hitbox',
      name: 'Hitbox Expander',
      cat: 'combat',
      desc: 'Aumenta sua hitbox para acertar mais facilmente',
      code: `local LP = game:GetService("Players").LocalPlayer
local size = 10
local hrp = LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
if hrp then
  hrp.Size = Vector3.new(size, size, size)
  print("[Hitbox] Expandida para " .. size)
end`,
    },
    {
      id: 'speed',
      name: 'Speed Hack',
      cat: 'combat',
      desc: 'Velocidade aumentada',
      code: `local LP = game:GetService("Players").LocalPlayer
local vel = 100
local hum = LP.Character and LP.Character:FindFirstChildOfClass("Humanoid")
if hum then
  hum.WalkSpeed = vel
  print("[Speed] " .. vel)
end`,
    },

    // ═══ FARM ═══
    {
      id: 'auto_farm',
      name: 'Auto Farm NPCs',
      cat: 'farm',
      desc: 'Teleporta para NPCs e os mata automaticamente',
      code: `local LP = game:GetService("Players").LocalPlayer
local RS = game:GetService("RunService")

local farming = true
print("[AutoFarm] Iniciado! Para parar: farming = false")

task.spawn(function()
  while farming do
    local hrp = LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
    if hrp then
      for _, v in ipairs(game.Workspace:GetDescendants()) do
        if not farming then break end
        if v:IsA("Humanoid") and v.Health > 0 and v.Parent ~= LP.Character then
          local root = v.Parent:FindFirstChild("HumanoidRootPart")
          if root then
            hrp.CFrame = root.CFrame + Vector3.new(0, 3, 0)
            task.wait(0.1)
            pcall(function() v.Health = 0 end)
            task.wait(0.2)
          end
        end
      end
    end
    task.wait(0.5)
  end
  print("[AutoFarm] Parado!")
end)`,
    },
    {
      id: 'auto_collect',
      name: 'Auto Coletar Items',
      cat: 'farm',
      desc: 'Coleta automaticamente todos os items do workspace',
      code: `local LP = game:GetService("Players").LocalPlayer
local hrp = LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
if not hrp then print("Sem personagem!") return end

local items = game.Workspace:FindFirstChild("Items")
if not items then print("Workspace.Items não encontrado!") return end

local count = 0
for _, item in ipairs(items:GetChildren()) do
  local p = item.PrimaryPart or item:FindFirstChildWhichIsA("BasePart")
  if p then
    hrp.CFrame = CFrame.new(p.Position + Vector3.new(0, 3, 0))
    task.wait(0.2)
    -- Ativa ProximityPrompts
    for _, pp in ipairs(item:GetDescendants()) do
      if pp:IsA("ProximityPrompt") then
        local old = pp.HoldDuration
        pp.HoldDuration = 0
        pcall(function() pp:InputHoldBegin() end)
        task.wait(0.1)
        pcall(function() pp:InputHoldEnd() end)
        pp.HoldDuration = old
      end
    end
    count += 1
  end
end
print("[AutoColetar] Coletados: " .. count .. " items")`,
    },

    // ═══ TROLL ═══
    {
      id: 'fling',
      name: 'Fling Players',
      cat: 'troll',
      desc: 'Arremessa outros jogadores',
      code: `local LP = game:GetService("Players").LocalPlayer
local target = nil -- nil = todos

for _, p in ipairs(game:GetService("Players"):GetPlayers()) do
  if p ~= LP and (target == nil or p.Name:lower() == target:lower()) then
    local hrp = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
    if hrp then
      local bv = Instance.new("BodyVelocity")
      bv.Velocity = Vector3.new(math.random(-200,200), 500, math.random(-200,200))
      bv.MaxForce = Vector3.new(1e9, 1e9, 1e9)
      bv.Parent = hrp
      game:GetService("Debris"):AddItem(bv, 0.5)
      print("[Fling] " .. p.Name)
    end
  end
end`,
    },
    {
      id: 'infinite_jump',
      name: 'Infinite Jump',
      cat: 'troll',
      desc: 'Pulo infinito',
      code: `local UIS = game:GetService("UserInputService")
local LP  = game:GetService("Players").LocalPlayer

UIS.JumpRequest:Connect(function()
  local h = LP.Character and LP.Character:FindFirstChildOfClass("Humanoid")
  if h then h:ChangeState(Enum.HumanoidStateType.Jumping) end
end)
print("[InfJump] Ativo!")`,
    },

    // ═══ VISUAL ═══
    {
      id: 'esp',
      name: 'Player ESP',
      cat: 'visual',
      desc: 'Mostra caixas e nomes de jogadores através das paredes',
      code: `local LP   = game:GetService("Players").LocalPlayer
local cam  = game.Workspace.CurrentCamera

-- Remove ESP antigo
for _, v in ipairs(cam:GetChildren()) do
  if v.Name == "NightESP" then v:Destroy() end
end

local function addESP(player)
  if player == LP then return end
  local function update()
    while player and player.Parent do
      local char = player.Character
      local hrp  = char and char:FindFirstChild("HumanoidRootPart")
      if hrp then
        local pos, onScreen = cam:WorldToViewportPoint(hrp.Position)
        if onScreen then
          -- Cria/atualiza BillboardGui
          local bb = char:FindFirstChild("NightESP_Bill")
          if not bb then
            bb = Instance.new("BillboardGui")
            bb.Name = "NightESP_Bill"
            bb.AlwaysOnTop = true
            bb.Size = UDim2.fromOffset(120, 30)
            bb.StudsOffset = Vector3.new(0, 3, 0)
            bb.Parent = hrp
            local lbl = Instance.new("TextLabel", bb)
            lbl.Size = UDim2.fromScale(1,1)
            lbl.BackgroundTransparency = 1
            lbl.TextColor3 = Color3.fromRGB(0, 240, 255)
            lbl.TextStrokeTransparency = 0
            lbl.Font = Enum.Font.GothamBold
            lbl.TextSize = 14
            lbl.Text = player.Name
          end
        end
      end
      task.wait(0.5)
    end
  end
  task.spawn(update)
end

for _, p in ipairs(game:GetService("Players"):GetPlayers()) do addESP(p) end
game:GetService("Players").PlayerAdded:Connect(addESP)
print("[ESP] Ativo!")`,
    },
    {
      id: 'fullbright',
      name: 'Fullbright',
      cat: 'visual',
      desc: 'Remove todas as sombras e escuridão',
      code: `local lighting = game:GetService("Lighting")
lighting.Ambient          = Color3.fromRGB(255, 255, 255)
lighting.Brightness       = 2
lighting.GlobalShadows    = false
lighting.FogEnd           = 9e9
lighting.FogStart         = 9e9

for _, v in ipairs(lighting:GetDescendants()) do
  if v:IsA("BlurEffect") or v:IsA("ColorCorrectionEffect")
    or v:IsA("SunRaysEffect") or v:IsA("DepthOfFieldEffect") then
    v.Enabled = false
  end
end
print("[Fullbright] Ativo!")`,
    },

    // ═══ MISC ═══
    {
      id: 'tp_server',
      name: 'TP para Todos',
      cat: 'misc',
      desc: 'Teleporta para cada jogador do servidor',
      code: `local LP = game:GetService("Players").LocalPlayer
for _, p in ipairs(game:GetService("Players"):GetPlayers()) do
  if p ~= LP then
    local hrp1 = LP.Character and LP.Character:FindFirstChild("HumanoidRootPart")
    local hrp2 = p.Character  and p.Character:FindFirstChild("HumanoidRootPart")
    if hrp1 and hrp2 then
      hrp1.CFrame = hrp2.CFrame + Vector3.new(2, 0, 0)
      print("[TP] -> " .. p.Name)
      task.wait(1)
    end
  end
end`,
    },
    {
      id: 'remote_spy',
      name: 'Remote Spy Simples',
      cat: 'misc',
      desc: 'Monitora FireServer de RemoteEvents',
      code: `local mt = getrawmetatable(game)
local old = mt.__namecall
setreadonly(mt, false)
mt.__namecall = newcclosure(function(self, ...)
  local method = getnamecallmethod()
  if method == "FireServer" or method == "InvokeServer" then
    local args = {...}
    print("[RemoteSpy] " .. tostring(self) .. " | " .. method)
    for i, v in ipairs(args) do
      print("  Arg" .. i .. ": " .. tostring(v))
    end
  end
  return old(self, ...)
end)
setreadonly(mt, true)
print("[RemoteSpy] Monitorando remotes!")`,
    },
    {
      id: 'print_remotes',
      name: 'Listar RemoteEvents',
      cat: 'misc',
      desc: 'Printa todos os RemoteEvents do jogo',
      code: `local RE = game:GetService("ReplicatedStorage"):FindFirstChild("RemoteEvents")
  or game:GetService("ReplicatedStorage")

print("=== REMOTES ===")
local count = 0
for _, v in ipairs(RE:GetDescendants()) do
  if v:IsA("RemoteEvent") or v:IsA("RemoteFunction") then
    print(v.Name .. " [" .. v.ClassName .. "]")
    count += 1
  end
end
print("Total: " .. count)`,
    },
    {
      id: 'noclip',
      name: 'NoClip',
      cat: 'misc',
      desc: 'Atravessa paredes',
      code: `local noclip = true
local RS = game:GetService("RunService")
local LP = game:GetService("Players").LocalPlayer

RS.Stepped:Connect(function()
  if noclip and LP.Character then
    for _, v in ipairs(LP.Character:GetDescendants()) do
      if v:IsA("BasePart") then
        v.CanCollide = false
      end
    end
  end
end)
print("[Noclip] Ativo! noclip=false para parar")`,
    },
  ];

  let currentCat    = 'all';
  let currentSearch = '';
  let savedScripts  = [];

  // ── FILTRAR ──────────────────────────────
  const filtered = () => {
    let list = [...BUILT_IN];

    // Adiciona salvos
    savedScripts = DB.getSavedScripts().map(s => ({
      ...s,
      id: 'saved_' + s.name,
      cat: 'saved',
      desc: 'Script salvo pelo usuário',
    }));
    if (currentCat === 'saved') list = savedScripts;
    else if (currentCat === 'all') list = [...list, ...savedScripts];
    else list = list.filter(s => s.cat === currentCat);

    if (currentSearch) {
      const q = currentSearch.toLowerCase();
      list = list.filter(s =>
        s.name.toLowerCase().includes(q) ||
        s.desc.toLowerCase().includes(q)
      );
    }
    return list;
  };

  // ── RENDERIZAR ───────────────────────────
  const render = () => {
    const list = document.getElementById('scList');
    if (!list) return;
    const items = filtered();

    if (!items.length) {
      list.innerHTML = '<div style="text-align:center;padding:40px;font-family:var(--mono);color:var(--text3);">Nenhum script encontrado</div>';
      return;
    }

    list.innerHTML = '';
    items.forEach(sc => {
      const fav = DB.isFav(sc.id);
      const card = document.createElement('div');
      card.className = 'sc-card';
      card.innerHTML = `
        <div class="sc-card-top">
          <div class="sc-card-title">${sc.name}</div>
          <span class="sc-tag ${sc.cat}">${sc.cat.toUpperCase()}</span>
        </div>
        <div class="sc-card-desc">${sc.desc}</div>
        <div class="sc-card-preview">${sc.code.substring(0, 150)}${sc.code.length > 150 ? '...' : ''}</div>
        <div class="sc-card-actions">
          <button class="sc-act exec" data-id="${sc.id}">⚡ Executar</button>
          <button class="sc-act load" data-id="${sc.id}">📋 Carregar</button>
          <button class="sc-act star ${fav ? 'starred' : ''}" data-id="${sc.id}">${fav ? '⭐' : '☆'}</button>
          ${sc.cat === 'saved' ? `<button class="sc-act del" data-name="${sc.name}">🗑</button>` : ''}
        </div>
      `;

      // Exec
      card.querySelector('.sc-act.exec').onclick = () => {
        Executor.run(sc.code);
        Toast.show('⚡ Executando: ' + sc.name);
      };
      // Load
      card.querySelector('.sc-act.load').onclick = () => {
        EditorMgr.setCode(sc.code, sc.name + '.lua');
        // Muda para tab editor
        document.querySelector('.tnav[data-tab="editor"]')?.click();
        Toast.show('✓ Carregado no editor!');
      };
      // Star
      card.querySelector('.sc-act.star').onclick = (e) => {
        const faved = DB.toggleFav(sc.id);
        e.target.textContent = faved ? '⭐' : '☆';
        e.target.classList.toggle('starred', faved);
      };
      // Delete (só salvos)
      card.querySelector('.sc-act.del')?.addEventListener('click', () => {
        if (confirm(`Deletar "${sc.name}"?`)) {
          DB.deleteScript(sc.name);
          render();
          Toast.show('🗑 Script deletado');
        }
      });

      list.appendChild(card);
    });
  };

  // ── INIT ─────────────────────────────────
  const init = () => {
    render();

    // Categorias
    document.getElementById('scCats')?.addEventListener('click', (e) => {
      const btn = e.target.closest('.sc-cat');
      if (!btn) return;
      document.querySelectorAll('.sc-cat').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentCat = btn.dataset.cat;
      render();
    });

    // Search
    const si = document.getElementById('scSearch');
    si?.addEventListener('input', () => {
      currentSearch = si.value;
      render();
    });

    document.getElementById('scClear')?.addEventListener('click', () => {
      if (si) si.value = '';
      currentSearch = '';
      render();
    });
  };

  return { init, render, BUILT_IN };
})();
