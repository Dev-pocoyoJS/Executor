/* ════════════════════════════════════════
   NightExec — editor.js
   Editor de código com multi-tabs
   ════════════════════════════════════════ */

const EditorMgr = (() => {
  let tabs       = [];
  let activeIdx  = 0;
  const history  = []; // undo stack simples
  let historyPos = -1;

  const area   = () => document.getElementById('codeEditor');
  const lnWrap = () => document.getElementById('lineNumbers');
  const tabBar = () => document.getElementById('tabBar');

  // ── INICIALIZAR ─────────────────────────
  const init = () => {
    tabs      = DB.getTabs();
    activeIdx = DB.getActiveTab();
    if (activeIdx >= tabs.length) activeIdx = 0;

    renderTabs();
    loadTab(activeIdx);
    bindEvents();
  };

  // ── RENDERIZAR ABAS ─────────────────────
  const renderTabs = () => {
    const bar = tabBar();
    bar.innerHTML = '';
    tabs.forEach((t, i) => {
      const div = document.createElement('div');
      div.className = 'etab' + (i === activeIdx ? ' active' : '');
      div.dataset.idx = i;
      div.innerHTML = `
        <span class="etab-name">${t.name}</span>
        <button class="etab-close" data-idx="${i}">×</button>
      `;
      div.addEventListener('click', (e) => {
        if (e.target.classList.contains('etab-close')) {
          closeTab(parseInt(e.target.dataset.idx));
        } else {
          switchTab(i);
        }
      });
      bar.appendChild(div);
    });
  };

  // ── CARREGAR ABA ─────────────────────────
  const loadTab = (i) => {
    const a = area();
    if (!a) return;
    a.value = tabs[i]?.code || '';
    updateLines();
    updateInfo();
    updateHistory(a.value);
  };

  // ── TROCAR ABA ───────────────────────────
  const switchTab = (i) => {
    // Salva código da aba atual
    tabs[activeIdx].code = area().value;
    activeIdx = i;
    renderTabs();
    loadTab(i);
    DB.saveTabs(tabs);
    DB.saveActiveTab(i);
  };

  // ── NOVA ABA ─────────────────────────────
  const newTab = (name, code = '') => {
    const n = name || `script_${tabs.length + 1}.lua`;
    tabs.push({ name: n, code });
    switchTab(tabs.length - 1);
  };

  // ── FECHAR ABA ───────────────────────────
  const closeTab = (i) => {
    if (tabs.length === 1) {
      tabs[0].code = '';
      loadTab(0);
      return;
    }
    tabs.splice(i, 1);
    if (activeIdx >= tabs.length) activeIdx = tabs.length - 1;
    renderTabs();
    loadTab(activeIdx);
    DB.saveTabs(tabs);
  };

  // ── LINHAS ───────────────────────────────
  const updateLines = () => {
    const a = area();
    if (!a) return;
    const lines = a.value.split('\n').length;
    const ln    = lnWrap();
    if (!ln) return;
    ln.textContent = Array.from({ length: lines }, (_, i) => i + 1).join('\n');
    syncScroll();
  };

  const syncScroll = () => {
    const a  = area();
    const ln = lnWrap();
    if (a && ln) ln.scrollTop = a.scrollTop;
  };

  // ── INFO STATUS BAR ──────────────────────
  const updateInfo = () => {
    const a = area();
    if (!a) return;
    const pos  = a.selectionStart;
    const text = a.value;
    const linesUntil = text.substring(0, pos).split('\n');
    const ln   = linesUntil.length;
    const col  = linesUntil[linesUntil.length - 1].length + 1;
    const chars = text.length;

    const ci = document.getElementById('cursorInfo');
    const ch = document.getElementById('charInfo');
    if (ci) ci.textContent = `Ln ${ln}, Col ${col}`;
    if (ch) ch.textContent = `${chars} chars`;
  };

  // ── UNDO/REDO SIMPLES ────────────────────
  const updateHistory = (code) => {
    if (history[historyPos] === code) return;
    history.splice(historyPos + 1);
    history.push(code);
    if (history.length > 100) history.shift();
    historyPos = history.length - 1;
  };

  const undo = () => {
    if (historyPos <= 0) return;
    historyPos--;
    area().value = history[historyPos];
    tabs[activeIdx].code = history[historyPos];
    updateLines();
  };

  const redo = () => {
    if (historyPos >= history.length - 1) return;
    historyPos++;
    area().value = history[historyPos];
    tabs[activeIdx].code = history[historyPos];
    updateLines();
  };

  // ── INSERIR TEXTO NA POSIÇÃO DO CURSOR ───
  const insertAt = (text) => {
    const a   = area();
    const s   = a.selectionStart;
    const e   = a.selectionEnd;
    const val = a.value;
    a.value   = val.slice(0, s) + text + val.slice(e);
    a.selectionStart = a.selectionEnd = s + text.length;
    a.focus();
    updateLines();
    updateInfo();
    saveCurrentTab();
  };

  // ── TAB KEY ──────────────────────────────
  const handleTab = (e) => {
    if (e.key !== 'Tab') return;
    e.preventDefault();
    const a     = area();
    const s     = a.selectionStart;
    const e2    = a.selectionEnd;
    const indent = '  '; // 2 espaços

    if (s === e2) {
      insertAt(indent);
    } else {
      // Indenta bloco selecionado
      const lines = a.value.split('\n');
      let start = a.value.substring(0, s).split('\n').length - 1;
      let end   = a.value.substring(0, e2).split('\n').length - 1;
      for (let i = start; i <= end; i++) {
        lines[i] = e.shiftKey
          ? lines[i].replace(/^  /, '')
          : indent + lines[i];
      }
      a.value = lines.join('\n');
      updateLines();
    }
  };

  // ── AUTO-FECHAMENTO DE BRACKETS ──────────
  const autoBracket = (e) => {
    const pairs = { '(': ')', '[': ']', '{': '}', '"': '"', "'": "'" };
    if (!pairs[e.key]) return;
    e.preventDefault();
    const a = area();
    const s = a.selectionStart;
    const sel = a.value.substring(a.selectionStart, a.selectionEnd);
    if (sel) {
      insertAt(e.key + sel + pairs[e.key]);
    } else {
      insertAt(e.key + pairs[e.key]);
      a.selectionStart = a.selectionEnd = s + 1;
    }
  };

  // ── SALVAR ABA ATUAL ─────────────────────
  const saveCurrentTab = () => {
    tabs[activeIdx].code = area().value;
    DB.saveTabs(tabs);
  };

  // ── OBTER CÓDIGO ─────────────────────────
  const getCode = () => area()?.value || '';

  // ── DEFINIR CÓDIGO ───────────────────────
  const setCode = (code, tabName) => {
    if (tabName) {
      tabs[activeIdx].name = tabName;
      renderTabs();
    }
    area().value = code;
    tabs[activeIdx].code = code;
    updateLines();
    updateInfo();
    updateHistory(code);
    saveCurrentTab();
  };

  // ── FORMATAR (básico) ────────────────────
  const format = () => {
    const code = getCode();
    // Formatação básica: indentação
    let level = 0;
    const result = code.split('\n').map(line => {
      const trim = line.trim();
      if (!trim) return '';

      const keywords_down = ['end', 'else', 'elseif', 'until'];
      const keywords_up   = ['do', 'then', 'else', 'repeat', 'function'];

      if (keywords_down.some(k => trim.startsWith(k))) level = Math.max(0, level - 1);
      const indented = '  '.repeat(level) + trim;
      if (keywords_up.some(k => trim.endsWith(k) || trim.includes(' ' + k + ' ') || trim.startsWith(k + ' ')))
        level++;

      return indented;
    }).join('\n');
    setCode(result);
    Toast.show('✓ Código formatado!');
  };

  // ── BIND EVENTS ──────────────────────────
  const bindEvents = () => {
    const a = area();
    if (!a) return;

    a.addEventListener('input', () => {
      updateLines();
      updateInfo();
      saveCurrentTab();
      updateHistory(a.value);
    });

    a.addEventListener('scroll', syncScroll);
    a.addEventListener('keyup',  updateInfo);
    a.addEventListener('click',  updateInfo);
    a.addEventListener('keydown', (e) => {
      handleTab(e);
      // Auto-bracket
      if (['(','[','{','"',"'"].includes(e.key)) autoBracket(e);
    });

    // Botões toolbar
    const b = (id, fn) => {
      const el = document.getElementById(id);
      if (el) el.onclick = fn;
    };

    b('btnNewTab',     () => newTab());
    b('btnUndo',       undo);
    b('btnRedo',       redo);
    b('btnCut',        () => { document.execCommand('cut'); saveCurrentTab(); });
    b('btnCopy',       () => { document.execCommand('copy'); Toast.show('✓ Copiado!'); });
    b('btnPaste',      async () => {
      try {
        const text = await navigator.clipboard.readText();
        insertAt(text);
      } catch { document.execCommand('paste'); }
    });
    b('btnSelectAll',  () => { a.select(); });
    b('btnClearEditor',() => { setCode(''); Toast.show('Editor limpo'); });
    b('btnFormat',     format);
    b('btnSaveScript', () => {
      const name = prompt('Nome do script:', tabs[activeIdx].name) || tabs[activeIdx].name;
      DB.saveScript(name, getCode());
      Toast.show('✓ Script salvo!');
    });
    b('btnOpen', () => document.getElementById('fileInput').click());

    // Snippets
    document.querySelectorAll('.tb-btn.snippet').forEach(btn => {
      btn.onclick = () => insertAt(btn.dataset.code || '');
    });

    // Abrir arquivo
    const fi = document.getElementById('fileInput');
    if (fi) {
      fi.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
          newTab(file.name, ev.target.result);
          Toast.show(`✓ ${file.name} carregado!`);
        };
        reader.readAsText(file);
        fi.value = '';
      };
    }

    // FontSize das settings
    document.addEventListener('nightexec:fontsize', (e) => {
      a.style.fontSize = e.detail + 'px';
      lnWrap().style.fontSize = e.detail + 'px';
    });
  };

  return { init, getCode, setCode, newTab, format, insertAt };
})();
