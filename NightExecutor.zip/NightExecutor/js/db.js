/* ════════════════════════════════════════
   NightExec — db.js
   Banco de dados local com localStorage
   ════════════════════════════════════════ */

const DB = (() => {
  const PREFIX = 'nightexec_';

  const get = (key, def = null) => {
    try {
      const v = localStorage.getItem(PREFIX + key);
      return v !== null ? JSON.parse(v) : def;
    } catch { return def; }
  };

  const set = (key, val) => {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(val)); return true; }
    catch { return false; }
  };

  const del = (key) => localStorage.removeItem(PREFIX + key);

  const clear = () => {
    Object.keys(localStorage)
      .filter(k => k.startsWith(PREFIX))
      .forEach(k => localStorage.removeItem(k));
  };

  // ── TABS (abas do editor) ───────────────
  const getTabs = () => get('tabs', [{ name: 'script_1.lua', code: '' }]);
  const saveTabs = (tabs) => set('tabs', tabs);
  const getActiveTab = () => get('activeTab', 0);
  const saveActiveTab = (i) => set('activeTab', i);

  // ── HISTÓRICO DE EXECUÇÃO ───────────────
  const getHistory = () => get('history', []);
  const addHistory = (code) => {
    const h = getHistory();
    h.unshift({ code, ts: Date.now() });
    if (h.length > 50) h.pop();
    set('history', h);
  };

  // ── SCRIPTS SALVOS PELO USUÁRIO ─────────
  const getSavedScripts = () => get('saved_scripts', []);
  const saveScript = (name, code) => {
    const s = getSavedScripts();
    const idx = s.findIndex(x => x.name === name);
    if (idx >= 0) s[idx] = { name, code, ts: Date.now() };
    else s.unshift({ name, code, ts: Date.now() });
    set('saved_scripts', s);
  };
  const deleteScript = (name) => {
    const s = getSavedScripts().filter(x => x.name !== name);
    set('saved_scripts', s);
  };

  // ── FAVORITOS ───────────────────────────
  const getFavs = () => get('favs', []);
  const toggleFav = (id) => {
    const f = getFavs();
    const idx = f.indexOf(id);
    if (idx >= 0) f.splice(idx, 1); else f.push(id);
    set('favs', f);
    return idx < 0; // true = favoritado
  };
  const isFav = (id) => getFavs().includes(id);

  // ── CONFIGURAÇÕES ───────────────────────
  const defaultSettings = {
    fontSize:     13,
    theme:        'dark',
    autoAttach:   false,
    notifications: true,
    keepHistory:  true,
    wordWrap:     false,
    tabSize:      2,
    opacity:      100,
  };
  const getSettings = () => ({ ...defaultSettings, ...get('settings', {}) });
  const saveSetting = (key, val) => {
    const s = getSettings();
    s[key] = val;
    set('settings', s);
  };

  // ── CONSOLE LOGS ───────────────────────
  const getLogs = () => get('logs', []);
  const addLog = (type, msg) => {
    const logs = getLogs();
    logs.push({ type, msg, ts: Date.now() });
    if (logs.length > 200) logs.splice(0, logs.length - 200);
    set('logs', logs);
  };

  return {
    get, set, del, clear,
    getTabs, saveTabs, getActiveTab, saveActiveTab,
    getHistory, addHistory,
    getSavedScripts, saveScript, deleteScript,
    getFavs, toggleFav, isFav,
    getSettings, saveSetting,
    getLogs, addLog,
  };
})();
