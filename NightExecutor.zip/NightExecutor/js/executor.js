/* ════════════════════════════════════════
   NightExec — executor.js
   Gerencia execução e attach
   ════════════════════════════════════════ */

const Executor = (() => {
  let attached  = false;
  let execCount = 0;

  // ── ATTACH ───────────────────────────────
  const attach = () => {
    // Simula tentativa de attach ao executor do dispositivo
    // Em uso real: integração com a API do executor (Delta, Solara etc.)
    ConsoleMgr.sys('Tentando attach...');

    // Simula delay de attach
    setTimeout(() => {
      attached = true;
      updateAttachUI(true);
      ConsoleMgr.sys('Attach realizado com sucesso!');
      Toast.show('✓ Attached!');
    }, 1200);
  };

  const detach = () => {
    attached = false;
    updateAttachUI(false);
    ConsoleMgr.sys('Detached.');
    Toast.show('Detached');
  };

  const toggleAttach = () => {
    if (attached) detach(); else attach();
  };

  const updateAttachUI = (isAttached) => {
    const btn  = document.getElementById('btnAttach');
    const dot  = document.getElementById('statusDot');
    const txt  = document.getElementById('statusTxt');
    const pill = document.getElementById('statusPill');

    if (btn) {
      btn.textContent = isAttached ? '✓ Attached' : '🔗 Attach';
      btn.classList.toggle('attached', isAttached);
    }
    if (dot) dot.classList.toggle('on', isAttached);
    if (txt) txt.textContent = isAttached ? 'Attached' : 'Offline';
  };

  // ── EXECUTAR ─────────────────────────────
  const run = (code) => {
    if (!code || !code.trim()) {
      Toast.show('⚠ Editor vazio!');
      return;
    }

    execCount++;
    const trimmed = code.trim();
    const preview = trimmed.length > 60
      ? trimmed.substring(0, 57) + '...'
      : trimmed;

    ConsoleMgr.sys(`Executando script #${execCount}...`);
    ConsoleMgr.log(preview.split('\n')[0]);

    if (DB.getSettings().keepHistory) {
      DB.addHistory(trimmed);
    }

    // ── INTEGRAÇÃO COM EXECUTOR REAL ───────
    // Cada executor expõe uma função global diferente:
    const executors = [
      () => typeof syn !== 'undefined'      && syn.request,      // Synapse X
      () => typeof KRNL_LOADED !== 'undefined',                   // KRNL
      () => typeof fluxus !== 'undefined',                        // Fluxus
      () => typeof Delta !== 'undefined',                         // Delta
      () => typeof Celery !== 'undefined',                        // Celery
      () => typeof getgenv !== 'undefined',                       // Solara/genérico
    ];

    let executorFound = false;
    for (const check of executors) {
      try {
        if (check()) { executorFound = true; break; }
      } catch {}
    }

    if (executorFound || attached) {
      try {
        // Tenta executar via função global padrão
        if (typeof loadstring === 'function') {
          loadstring(code)();
        } else if (typeof syn?.execute === 'function') {
          syn.execute(code);
        } else if (typeof fluxus?.execute === 'function') {
          fluxus.execute(code);
        } else {
          // Fallback: função padrão de executores mobile
          (new Function(code))();
        }
        ConsoleMgr.sys(`✓ Script #${execCount} executado`);
        if (DB.getSettings().notifications) {
          Toast.show('⚡ Script executado!');
        }
      } catch (e) {
        ConsoleMgr.err('Erro de execução: ' + e.message);
        Toast.show('✗ Erro: ' + e.message.substring(0, 40));
      }
    } else {
      // Modo demo (sem executor)
      ConsoleMgr.warn('Executor não detectado — modo demo');
      ConsoleMgr.log('Script pronto para execução quando attached');
      Toast.show('⚠ Sem executor — faça Attach primeiro');
    }
  };

  // ── INIT ─────────────────────────────────
  const init = () => {
    document.getElementById('btnExec')?.addEventListener('click', () => {
      run(EditorMgr.getCode());
    });

    document.getElementById('btnAttach')?.addEventListener('click', toggleAttach);
    document.getElementById('sbAttach')?.addEventListener('click', () => {
      toggleAttach();
      Sidebar.close();
    });

    // Auto attach se configurado
    if (DB.getSettings().autoAttach) {
      setTimeout(attach, 1500);
    }
  };

  return { init, run, attach, detach, isAttached: () => attached };
})();
