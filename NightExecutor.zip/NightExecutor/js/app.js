/* ════════════════════════════════════════
   NightExec — app.js
   Bootstrap principal e navegação
   ════════════════════════════════════════ */

// ── TOAST ─────────────────────────────────
const Toast = (() => {
  let timer = null;
  const el  = () => document.getElementById('toast');

  const show = (msg, duration = 2200) => {
    const t = el();
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(timer);
    timer = setTimeout(() => t.classList.remove('show'), duration);
  };
  return { show };
})();

// ── SIDEBAR ───────────────────────────────
const Sidebar = (() => {
  const sb  = () => document.getElementById('sidebar');
  const ov  = () => document.getElementById('sbOverlay');

  const open = () => {
    sb()?.classList.remove('hidden');
    sb()?.classList.add('open');
    ov()?.classList.remove('hidden');
  };
  const close = () => {
    sb()?.classList.remove('open');
    ov()?.classList.add('hidden');
    setTimeout(() => sb()?.classList.add('hidden'), 300);
  };
  const toggle = () => {
    sb()?.classList.contains('open') ? close() : open();
  };

  const init = () => {
    document.getElementById('menuBtn')?.addEventListener('click', toggle);
    document.getElementById('sbClose')?.addEventListener('click', close);
    ov()?.addEventListener('click', close);

    // Nav items do sidebar
    document.querySelectorAll('.sb-item[data-tab]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const tab = item.dataset.tab;
        if (tab) switchTab(tab);
        close();
      });
    });

    // Ação: Sources
    document.getElementById('sbFetchSources')?.addEventListener('click', () => {
      SourceUI.open(true);
      close();
    });

    // Ação: Clear all
    document.getElementById('sbClearAll')?.addEventListener('click', () => {
      EditorMgr.setCode('');
      ConsoleMgr.clear();
      close();
      Toast.show('✓ Tudo limpo');
    });

    // Ação: Export logs
    document.getElementById('sbExportLogs')?.addEventListener('click', () => {
      const logs = DB.getLogs();
      const txt  = logs.map(l => `[${l.type.toUpperCase()}] ${new Date(l.ts).toLocaleTimeString()} ${l.msg}`).join('\n');
      const blob = new Blob([txt], { type: 'text/plain' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = 'nightexec_logs.txt';
      a.click();
      URL.revokeObjectURL(url);
      close();
      Toast.show('✓ Logs exportados!');
    });
  };

  return { init, open, close, toggle };
})();

// ── NAVEGAÇÃO DE TABS ─────────────────────
const switchTab = (tabId) => {
  document.querySelectorAll('.tnav').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === tabId);
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === 'panel-' + tabId);
  });
};

// ── SPLASH LOADER ─────────────────────────
const runSplash = (onDone) => {
  const bar    = document.getElementById('splashBar');
  const status = document.getElementById('splashStatus');
  const steps  = [
    [10,  'Inicializando engine...'],
    [25,  'Carregando scripts embutidos...'],
    [45,  'Configurando editor...'],
    [65,  'Preparando console...'],
    [80,  'Aplicando configurações...'],
    [95,  'Quase pronto...'],
    [100, 'Pronto!'],
  ];

  let i = 0;
  const next = () => {
    if (i >= steps.length) {
      setTimeout(() => {
        document.getElementById('splash')?.classList.add('out');
        setTimeout(onDone, 500);
      }, 200);
      return;
    }
    const [pct, msg] = steps[i++];
    if (bar)    bar.style.width = pct + '%';
    if (status) status.textContent = msg;
    setTimeout(next, 180 + Math.random() * 120);
  };
  next();
};

// ── TABS NAV ──────────────────────────────
const initTabs = () => {
  document.querySelectorAll('.tnav').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });
};

// ── SWIPE PARA TROCAR TABS ────────────────
const initSwipe = () => {
  const tabs  = ['editor', 'scripts', 'console', 'settings'];
  let startX  = 0;
  let startY  = 0;

  document.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });

  document.addEventListener('touchend', (e) => {
    const dx = e.changedTouches[0].clientX - startX;
    const dy = e.changedTouches[0].clientY - startY;

    // Só detecta swipe horizontal
    if (Math.abs(dx) < 60 || Math.abs(dy) > Math.abs(dx) * 0.6) return;

    const activeBtn = document.querySelector('.tnav.active');
    if (!activeBtn) return;
    const idx = tabs.indexOf(activeBtn.dataset.tab);

    if (dx < 0 && idx < tabs.length - 1) switchTab(tabs[idx + 1]);
    if (dx > 0 && idx > 0)               switchTab(tabs[idx - 1]);
  }, { passive: true });
};

// ── ATALHOS DE TECLADO ────────────────────
const initKeyboard = () => {
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'Enter') {
        e.preventDefault();
        Executor.run(EditorMgr.getCode());
      } else if (e.key === 's') {
        e.preventDefault();
        DB.saveScript(
          document.querySelector('.etab.active .etab-name')?.textContent || 'script.lua',
          EditorMgr.getCode()
        );
        Toast.show('✓ Salvo!');
      }
    }
  });
};

// ── EVITAR ZOOM NO MOBILE ─────────────────
document.addEventListener('gesturestart', e => e.preventDefault(), { passive: false });
document.addEventListener('dblclick', e => e.preventDefault(), { passive: false });

// ── BOOTSTRAP PRINCIPAL ───────────────────
window.addEventListener('DOMContentLoaded', () => {
  runSplash(() => {
    // Mostra app
    document.getElementById('app')?.classList.remove('hidden');

    // Inicializa módulos
    EditorMgr.init();
    ConsoleMgr.init();
    ScriptsMgr.init();
    SettingsMgr.init();
    Executor.init();
    SourceUI.init();
    Sidebar.init();
    initTabs();
    initSwipe();
    initKeyboard();

    ConsoleMgr.sys('Todos os módulos carregados ✓');
  });
});
